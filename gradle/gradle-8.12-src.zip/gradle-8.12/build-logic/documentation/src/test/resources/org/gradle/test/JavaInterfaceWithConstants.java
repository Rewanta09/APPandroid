package org.gradle.test;

public interface JavaInterfaceWithConstants {
    String STRING_CONST = "some-string";
    public static final int INT_CONST = 120;
}
